# 🔥 BOT DE TWITTER REGENERADO - IBIZAGIRL.PICS 🔥

## ✅ REGENERADO CON NUEVAS CREDENCIALES 2025

**¡Bot completamente regenerado con tus nuevas credenciales de Twitter!**

### 🔑 CREDENCIALES INCLUIDAS:
- ✅ API Key: `Zk2cHPPfhUsDIaPH77WAWuAQl`
- ✅ API Secret: `Q2z38G3AIp0cF5ZVikGLopRmwPpD24ca79lJpgUirrb5r065Hl`
- ✅ Access Token: `1163515914731626497-hyI437ByyuqxVD8py99n1rWU8Mjnjs`
- ✅ Access Secret: `EeOD2LS0H2Z5qPKVxN0miLk2txyN05VdcRcnb2AqbH0wr`

## 🚀 INSTRUCCIONES PASO A PASO:

### **1. Instalar dependencias:**
```bash
cd twitter-bot-ibiza
npm install
```

### **2. Verificar nuevas credenciales:**
```bash
npm run check
```
Deberías ver:
```
🔑 API Key: true
🔑 Secret: true  
🔑 Token: true
```

### **3. Ejecutar bot regenerado:**
```bash
npm start
```
O directamente:
```bash
node twitter-bot-REGENERADO.js
```

### **4. Monitorear funcionamiento:**
```bash
npm run logs
```

## 🛡️ PROTECCIONES MEJORADAS:

### **Rate Limiting Ultra Conservador:**
- ⏰ **5 minutos** mínimo entre tweets
- 📊 **8 tweets máximo** cada 15 minutos
- 🗓️ **15 tweets máximo** por día
- 🔄 **3 reintentos** con backoff exponencial

### **Manejo de Errores Avanzado:**
- ✅ Error 401: Detecta credenciales inválidas
- ✅ Error 429: Espera automática con delays incrementales
- ✅ Error 403: Evita contenido duplicado
- ✅ Logging detallado en `logs/twitter-bot.log`

### **Búsqueda Inteligente de Imágenes:**
Busca automáticamente en:
- `../full/`
- `./full/` 
- `./images/`
- `/Users/oriolcabre/Desktop/ibizagirl/full/`
- Y más ubicaciones...

## 📅 PROGRAMACIÓN CONSERVADORA:

- **🖼️ Tweet con imagen:** cada 12 horas (2/día)
- **📝 Tweet de texto:** cada 16 horas (1-2/día)  
- **⭐ Tweet especial:** 1 vez al día (14:30h)
- **🔄 Reset contadores:** cada 15 minutos
- **🌅 Reset diario:** medianoche

## 📊 ESTADÍSTICAS EN TIEMPO REAL:

El bot muestra:
```
📊 === ESTADÍSTICAS DEL BOT REGENERADO ===
🕐 Fecha/Hora: 20/8/2025, 10:30:15
🐦 Tweets hoy: 3/15
📈 Tweets (15min): 1/8
❌ Errores consecutivos: 0
📝 Templates: 10 disponibles
#️⃣ Hashtag sets: 4 rotativos
```

## 🔧 COMANDOS ÚTILES:

```bash
# Iniciar bot
npm start

# Verificar credenciales
npm run check

# Ver logs en tiempo real  
npm run logs

# Ver procesos activos
npm run status

# Parar bot (Ctrl+C en terminal activo)
```

## 📁 ARCHIVOS DEL BOT REGENERADO:

- `twitter-bot-REGENERADO.js` ← **USAR ESTE**
- `twitter-NEW.env` ← Nuevas credenciales  
- `package-REGENERADO.json` ← Configuración actualizada
- `logs/twitter-bot.log` ← Logs detallados (se crea automáticamente)

## ⚠️ IMPORTANTE:

- **NO usar** los archivos antiguos (`twitter-bot.js`, `twitter.env`)
- **SÍ usar** los archivos REGENERADOS
- El bot necesita encontrar imágenes para tweets con foto
- Mantén el terminal abierto mientras el bot funciona
- Los logs se guardan automáticamente en `logs/`

## 🎯 PRIMERA EJECUCIÓN:

1. **Terminal 1 (ejecutar bot):**
```bash
cd twitter-bot-ibiza
node twitter-bot-REGENERADO.js
```

2. **Terminal 2 (monitorear logs):**
```bash
cd twitter-bot-ibiza  
tail -f logs/twitter-bot.log
```

## ✅ RESULTADO ESPERADO:

```
🔥 IBIZAGIRL.PICS TWITTER BOT - REGENERADO 2025 🔥
🔑 Con nuevas credenciales y protección máxima 🔑

🔐 Probando nuevas credenciales...
✅ ¡CONECTADO EXITOSAMENTE!
👤 Usuario: @tu_usuario
👥 Followers: XXX
📝 Tweets: XXX

✅ BOT REGENERADO FUNCIONANDO - Modo Ultra Seguro Activado
🛡️ Protección máxima contra errores 429
```

## 🆘 SI HAY PROBLEMAS:

1. **Error de conexión:** Verifica `twitter-NEW.env`
2. **Error 429:** El bot esperará automáticamente
3. **Sin imágenes:** Asegúrate que existe carpeta `full/` con imágenes
4. **Otros errores:** Revisa `logs/twitter-bot.log`

¡Bot regenerado listo para funcionar sin errores! 🎉